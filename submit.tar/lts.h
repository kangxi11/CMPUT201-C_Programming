#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "lcs.h"
#include "random.h"

void lts(char s[], char lpsString[]);
void lcts(char s1[], char s2[], char rs[]);