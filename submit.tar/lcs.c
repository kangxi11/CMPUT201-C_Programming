#include "lcs.h"

struct tuple
{
    int row;
    int col;

    char num;

    int prev_row;
    int prev_col;

    bool used;
};

void DFS(int strow, int stcol, int **table, struct tuple res[], int ori_row, int ori_col, char s1[], char s2[])
{
    int level = table[strow][stcol];

    if ((stcol > 0) && (table[strow][stcol - 1] == level))
    {
        DFS(strow, stcol - 1, table, res, ori_row, ori_col, s1, s2);
    }
    if ((strow > 0) && (table[strow - 1][stcol] == level))
    {
        DFS(strow - 1, stcol, table, res, ori_row, ori_col, s1, s2);
    }
    if ((stcol > 0) && (strow > 0) && (s2[strow - 1] == s1[stcol - 1]))
    {
        int i = 0;
        bool repeat = false;

        while (res[i].used)
        {
            if ((res[i].row == strow) && (res[i].col == stcol) && (res[i].prev_row == ori_row) && (res[i].prev_col == ori_col))
            {
                repeat = true;
                break;
            }
            i++;
        }

        if (!repeat)
        {
            res[c].row = strow;
            res[c].col = stcol;
            res[c].prev_row = ori_row;
            res[c].prev_col = ori_col;
            res[c].used = true;
            res[c].num = s1[stcol - 1];
            c++;
        }
    }
}

void traverse(struct tuple res[], int row, int col, char str[], char **str_list, int max_length, char temp[])
{
    int i = 0;
    while (res[i].used)
    {
        if ((res[i].prev_row == row) && (res[i].prev_col == col))
        {
            strcpy(temp, str);
            strncat(temp, &res[i].num, 1);

            if (strlen(temp) == max_length)
            {
                // make sure it is not already in the list
                int l = 0;
                bool repeat = false;

                while (str_list[l][0] != '\0')
                {
                    if (strcmp(str_list[l], temp) == 0)
                    {
                        repeat = true;
                        break;
                    }
                    l++;
                }

                if (!repeat)
                    strcpy(str_list[pos++], temp);
                    memset(temp, 0, MAX);
            }

            traverse(res, res[i].row, res[i].col, temp, str_list, max_length, temp);
        }
        i++;
    }
}

void reverse(char str[], int lcs_i)
{
    char *p = str;
    char *p_end = str + lcs_i - 1;
    char temp;
    while (p < p_end)
    {
        temp = *p;
        *p++ = *p_end;
        *p_end-- = temp;
    }
}

void lcs(char s1[], char s2[], char *lcs_string, char **str_list)
{
    // finding the LCS of the two sequence of numbers
    int s1_len = strlen(s1);
    int s2_len = strlen(s2);

    // dynamically allocating a 2D array of up to 10 000 by 10 000
    int **lcs_table = (int **)malloc((s2_len + 1) * sizeof(int *)); // [rows][columns]
    //int **lcs_temp = lcs_table_original;
    for (int i = 0; i < s2_len + 1; i++)
    {
        lcs_table[i] = (int *)malloc((s1_len + 1) * sizeof(int));
    }

    /* s1 will be the columns and s2 will be the rows
  //    s1[0] s1[1] s1[2] s1[3] ......
  s2[0]______|_____|_____|______|.....
  s2[1]______|_____|_____|______|.....
  s2[2]______|_____|_____|______|.....
  s2[3]______|_____|_____|______|.....
  .
  .
  .

  */

    // making sure each of the elements in the array is 0 to start
    for (int i = 0; i < s2_len + 1; i++)
    {
        for (int j = 0; j < s1_len + 1; j++)
        {
            lcs_table[i][j] = 0;
        }
    }

    // creating the table that holds the LCS path
    for (int row = 0; row < s2_len; row++)
    {
        for (int col = 0; col < s1_len; col++)
        {
            if (s2[row] == s1[col])
            {
                // if equal, add one to the number to its diagonal left (up 1 left 1)
                lcs_table[row + 1][col + 1] = lcs_table[row][col] + 1;
            }
            else
            {
                // if not equal copy the highest number of its neighbour directly up
                // or directly to the left
                if (lcs_table[row + 1][col] > lcs_table[row][col + 1])
                {
                    lcs_table[row + 1][col + 1] = lcs_table[row + 1][col];
                }
                else
                {
                    lcs_table[row + 1][col + 1] = lcs_table[row][col + 1];
                }
            }
        }
    }

    struct tuple *res = (struct tuple *)malloc((MAX * MAX) * sizeof(struct tuple));

    for (int i = 0; i < sizeof(res) / sizeof(res[0]); i++)
        res[i].used = false;

    c = 0;

    int coord[2] = {s2_len, s1_len};
    int start = 0;

    DFS(coord[0], coord[1], lcs_table, res, -1, -1, s1, s2);

    while (start < c)
    {
        coord[0] = res[start].row;
        coord[1] = res[start].col;
        start++;
        DFS(coord[0] - 1, coord[1] - 1, lcs_table, res, coord[0], coord[1], s1, s2);
    }

    char *temp_string = (char *)malloc(MAX * sizeof(char));
    temp_string[0] = '\0';

    pos = 0;
    char *temp = (char *)malloc(MAX * sizeof(char));

    traverse(res, -1, -1, temp_string, str_list, lcs_table[s2_len][s1_len], temp);

    free(temp);

    int i = 0;
    while (str_list[i][0] != '\0')
    {
        reverse(str_list[i], lcs_table[s2_len][s1_len]);
        i++;
    }

    i = 0;

    strcpy(lcs_string, str_list[0]);

    for (int k = 0; k < s2_len + 1; k++)
    {
        free(lcs_table[k]);
    }
    free(lcs_table);
    free(res);
    free(temp_string);
}