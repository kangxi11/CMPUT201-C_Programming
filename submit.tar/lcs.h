#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "random.h"

extern int c;
extern int pos;

void lcs(char s1[], char s2[], char *lcs_string, char **str_list);
