#include "lts.h"

void lcts(char s1[], char s2[], char rs[])
{
    // first find all of the LCS between these two strings
    char **str_list_lcts = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        str_list_lcts[i] = (char *)malloc((MAX) * sizeof(char));
        str_list_lcts[i][0] = '\0';
    }
    char **lts_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        lts_list[i] = (char *)malloc((MAX) * sizeof(char));
        lts_list[i][0] = '\0';
    }

    char *longest_lts = (char *)malloc(MAX * sizeof(char));
    longest_lts[0] = '\0';

    lcs(s1, s2, rs, str_list_lcts);

    // now run LTS on each LCS and print the longest one
    int i = 0;
    while (str_list_lcts[i][0] != '\0')
    {
        char *ltsString = (char *)malloc((MAX) * sizeof(char));
        ltsString[0] = '\0';
        lts(str_list_lcts[i], ltsString);
        strcpy(lts_list[i], ltsString);

        free(ltsString);

        if (strlen(lts_list[i]) > strlen(longest_lts))
        {
            strcpy(longest_lts, lts_list[i]);
        }
        i++;
    }

    strcpy(rs, longest_lts);
    rs[strlen(rs)] = '\0';

    for (int k = 0; k < MAX; k++)
    {
        free(str_list_lcts[k]);
    }
    free(str_list_lcts);
    for (int k = 0; k < MAX; k++)
    {
        free(lts_list[k]);
    }
    free(lts_list);
    free(longest_lts);
}

void lts(char s[], char ltsString[])
{
    // edge case the string is empty
    if (strlen(s) == 0)
    {
        //printf("# an LTS (length = 0) for the first sequence is: \n");
        return;
    }
    int pivot = 0;         // index which splits the string
    int pivotDistance = 1; // how many indexes away from index we split
    int s_len = strlen(s);
    int len_max = 0; // max LTS length

    char **str_list_lts = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        str_list_lts[i] = (char *)malloc((MAX) * sizeof(char));
        str_list_lts[i][0] = '\0';
    }

    char *s_right = (char *)malloc(MAX * sizeof(char));
    char *s_left = (char *)malloc(MAX * sizeof(char));
    char *lts_temp = (char *)malloc(MAX * sizeof(char));

    // assume that the LTS is from splitting the sequence in half.
    // then check either side until one side is equal to the length of the
    // current LTS (because it's impossible afterwards)

    // first find the pivot that gives the largest len
    // done by checking every sqrt()th interval

    float temp, sqrt;
    sqrt = s_len / 2;
    temp = 0;
    while (sqrt != temp)
    {
        temp = sqrt;
        sqrt = (s_len / temp + temp) / 2;
    }

    int interval = sqrt;
    int i = interval;

    while (i <= s_len - interval)
    {
        // using memset to reset the strings so it doesn't conflict later
        memset(s_left, 0, MAX);
        memset(s_right, 0, MAX);
        strncpy(s_left, s, i);
        strncpy(s_right, s + i, s_len - i);

        lcs(s_left, s_right, lts_temp, str_list_lts);

        if (strlen(lts_temp) > len_max)
        {
            strcpy(ltsString, lts_temp); // using = would bind their memory address
            len_max = strlen(ltsString);
            pivot = i;
        }
        memset(lts_temp, 0, MAX);
        i += interval;
    }

    do
    { // now check either side until one side becomes too small

        // move the pivot to the right
        memset(s_left, 0, MAX);
        memset(s_right, 0, MAX);
        strncpy(s_left, s, pivot + pivotDistance);
        strncpy(s_right, s + pivot + pivotDistance, (s_len - pivot) - pivotDistance + 1);

        lcs(s_left, s_right, lts_temp, str_list_lts);

        if (strlen(lts_temp) > len_max)
        {
            strcpy(ltsString, lts_temp); // using = would bind their memory address
            len_max = strlen(ltsString);
        }
        memset(lts_temp, 0, MAX);

        // move the pivot to the left

        if (strlen(ltsString) > 0)
        {
            memset(s_left, 0, strlen(s_left)); // reset both of the char arrays
            memset(s_right, 0, strlen(s_right));
            strncpy(s_left, s, pivot - pivotDistance);
            strncpy(s_right, s + pivot - pivotDistance, (s_len - pivot) + pivotDistance);

            lcs(s_left, s_right, lts_temp, str_list_lts);

            if (strlen(lts_temp) > len_max)
            {
                strcpy(ltsString, lts_temp); // using = would bind their memory address
                len_max = strlen(ltsString);
            }
            memset(lts_temp, 0, strlen(lts_temp)); // reset lts_temp
        }
        pivotDistance++;
    } while ((pivotDistance <= interval + 1) && (strlen(s_left) > len_max) && (strlen(s_right) > len_max));

    //printf("# an LTS (length = %d) for the first seqence is: \n%s%s\n", len_max*2, ltsString, ltsString);
    for (int k = 0; k < MAX; k++)
    {
        free(str_list_lts[k]);
    }
    free(str_list_lts);
    free(s_left);
    free(s_right);
    free(lts_temp);
}