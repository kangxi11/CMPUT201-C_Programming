#include "lps.h"

void lcps(char s1[], char s2[], char rs[])
{
    // first find all of the LCS between these two strings
    char **str_list_lcps = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        str_list_lcps[i] = (char *)malloc((MAX) * sizeof(char));
        str_list_lcps[i][0] = '\0';
    }
    char **lps_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        lps_list[i] = (char *)malloc((MAX) * sizeof(char));
        lps_list[i][0] = '\0';
    }

    char *longest_lps = (char *)malloc(MAX * sizeof(char));
    longest_lps[0] = '\0';

    lcs(s1, s2, rs, str_list_lcps);

    // now run LPS on each LCS and print the longest one
    int i = 0;
    while (str_list_lcps[i][0] != '\0')
    {
        char *lpsString = (char *)malloc((MAX) * sizeof(char));
        lps(str_list_lcps[i], lpsString);
        strcpy(lps_list[i], lpsString);

        free(lpsString);

        if (strlen(lps_list[i]) > strlen(longest_lps))
        {
            strcpy(longest_lps, lps_list[i]);
        }
        i++;
    }
    strcpy(rs, longest_lps);
    rs[strlen(rs)] = '\0';

    for (int k = 0; k < MAX; k++)
    {
        free(str_list_lcps[k]);
    }
    free(str_list_lcps);
    for (int k = 0; k < MAX; k++)
    {
        free(lps_list[k]);
    }
    free(lps_list);
    free(longest_lps);
}

void lps(char s[], char lpsString[])
{
    char **str_list_lps = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
    for (int i = 0; i < MAX; i++)
    {
        str_list_lps[i] = (char *)malloc((MAX) * sizeof(char));
        str_list_lps[i][0] = '\0';
    }

    // edge case the string is empty
    if (strlen(s) == 0)
    {
        return;
    }
    char *s_reversed = (char *)malloc(MAX * sizeof(char));

    // create a string that is the reverse of s
    int j = 0;
    for (int i = strlen(s) - 1; i >= 0; i--)
    {
        s_reversed[j++] = s[i];
    }
    s_reversed[j] = '\0'; // correctly terminates the string with a NULL

    // to find longest palindrome, find the longest common subsequence between string and
    // revered version of itself

    lcs(s, s_reversed, lpsString, str_list_lps);

    //printf("# an LPS (length = %d) for the second sequence is: \n%s\n", (int)strlen(lpsString), lpsString);
    for (int k = 0; k < MAX; k++)
    {
        free(str_list_lps[k]);
    }
    free(str_list_lps);
    free(s_reversed);
}