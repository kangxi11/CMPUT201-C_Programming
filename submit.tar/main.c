/*
Submitting student: Ryan Kang (1543686)

Collaborating Classmates: N/A

Other collaborators: N/A

References:
*/

#include "main.h"

int main(int argc, char **argv)
{
    // allocating memory dynamically for the two strings up to 10 000
    // checking that the sequences only contain 0-9 digits

    bool out_read = false;

    FILE *inp_file = NULL;
    FILE *out_file = NULL;

    char *s1 = (char *)malloc(MAX * sizeof(char));
    char *s2 = (char *)malloc(MAX * sizeof(char));

    s1[0] = '\0';
    s2[0] = '\0';

    // iterate through argv and initiate file if found

    
    for (int i = 0; i < argc; i++)
    {
        if (strcmp(argv[i], "-o") == 0)
        {
            
            out_file = fopen(argv[i+1], "a");
            if (out_file == NULL)
            {
                printf("Could not open output file\n");
                return -1;
            }

            out_read = true;
        }
        if (strcmp(argv[i], "-i") == 0)
        {
            inp_file = fopen(argv[i+1], "r");
            if (inp_file == NULL)
            {
                printf("Could not open input file\n");
                return -1;
            }

            int i = 0;
            char ch;
            while ((ch = fgetc(inp_file)) != '\n')
            {
                if (ch < '0' || ch > '9')
                {
                    printf("Error, non-digit character detected!\n");
                    return -1;
                }
                s1[i++] = ch;
            }
            s1[i] = '\0';

            i = 0;
            while ((ch = fgetc(inp_file)) != '\n')
            {
                if (ch < '0' || ch > '9')
                {
                    printf("Error, non-digit character detected!\n");
                    return -1;
                }
                s2[i++] = ch;
            }
            s2[i] = '\0';
        }
    }
    for (int i = 0; i < argc; i++)
    {
        if (strcmp(argv[i], "-g") == 0)
        {
            char *g1 = (char *)malloc(MAX * sizeof(char));
            char *g2 = (char *)malloc(MAX * sizeof(char));

            int g1_len;
            int g2_len;

            printf("Enter the lengths of the two sequences:");
            scanf("%d%d", &g1_len, &g2_len);

            generate(g1_len, g1);
            generate(g2_len, g2);


            if (!out_read)
            {
                printf("%s\n%s\n", g1, g2);
            }
            else
            {
                fprintf(out_file, "%s\n%s\n\n", g1, g2);
            }

            free(g1);
            free(g2);
        }

        
        if (strcmp(argv[i], "-c") == 0)
        {
            if ((inp_file == NULL) && (strlen(s1) == 0) && (strlen(s2) == 0))
            {
                // read in the input manually
                getString(s1);
                getString(s2);
            }

            char **str_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
            for (int i = 0; i < MAX; i++)
            {
                str_list[i] = (char *)malloc((MAX) * sizeof(char));
                str_list[i][0] = '\0';
            }

            char *rs = (char *)malloc(MAX * sizeof(char));

            // how find the LCS for s1 and s2
            lcs(s1, s2, rs, str_list);

            // see if there is an output file
            if (!out_read)
            {
                printf("# an LCS (length = %zu) for the two sequences is:\n%s\n", strlen(rs), rs);
            } else
            {
                fprintf(out_file, "# an LCS (length = %zu) for the two sequences is:\n%s\n", strlen(rs), rs);
            }

            for (int k = 0; k < MAX; k++)
            {
                free(str_list[k]);
            }
            free(str_list);
            free(rs);
        }

        
        if (strcmp(argv[i], "-ct") == 0)
        {
            if ((inp_file == NULL) && (strlen(s1) == 0) && (strlen(s2) == 0))
            {
                // read in the input manually
                getString(s1);
                getString(s2);
            }

            char **str_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
            for (int i = 0; i < MAX; i++)
            {
                str_list[i] = (char *)malloc((MAX) * sizeof(char));
                str_list[i][0] = '\0';
            }
            char *rs = (char *)malloc(MAX * sizeof(char));

            // how find the LCS for s1 and s2
            lcts(s1, s2, rs);

            // see if there is an output file

            if (!out_read)
            {
                printf("# an LCTS (length = %zu) for the two sequences is:\n%s%s\n", strlen(rs)*2, rs, rs);
            }
            else
            {
                fprintf(out_file, "# an LCTS (length = %zu) for the two sequences is:\n%s%s\n", strlen(rs)*2, rs, rs);
            }

            for (int k = 0; k < MAX; k++)
            {
                free(str_list[k]);
            }
            free(str_list);
            free(rs);
        }

        if (strcmp(argv[i], "-cp") == 0)
        {
            if ((inp_file == NULL) && (strlen(s1) == 0) && (strlen(s2) == 0))
            {
                // read in the input manually
                getString(s1);
                getString(s2);
            }

            char **str_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
            for (int i = 0; i < MAX; i++)
            {
                str_list[i] = (char *)malloc((MAX) * sizeof(char));
                str_list[i][0] = '\0';
            }
            char *rs = (char *)malloc(MAX * sizeof(char));

            // how find the LCS for s1 and s2
            lcps(s1, s2, rs);

            // see if there is an output file
            if (!out_read)
            {
                printf("# an LCPS (length = %zu) for the two sequences is:\n%s\n", strlen(rs), rs);
            }
            else
            {
                fprintf(out_file, "# an LCPS (length = %zu) for the two sequences is:\n%s\n", strlen(rs), rs);
            }

            for (int k = 0; k < MAX; k++)
            {
                free(str_list[k]);
            }
            free(str_list);
            free(rs);
        }

        if (strcmp(argv[i], "-t") == 0)
        {
            if ((inp_file == NULL) && (strlen(s1) == 0))
            {
                // read in the input manually
                getString(s1);
            }

            char **str_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
            for (int i = 0; i < MAX; i++)
            {
                str_list[i] = (char *)malloc((MAX) * sizeof(char));
                str_list[i][0] = '\0';
            }
            char *rs = (char *)malloc(MAX * sizeof(char));

            // how find the LCS for s1 and s2
            lts(s1, rs);
            // see if there is an output file

            if (!out_read)
            {
                printf("# an LTS (length = %zu) for the sequences is:\n%s%s\n", strlen(rs)*2, rs, rs);
            }
            else
            {
                fprintf(out_file, "# an LTS (length = %zu) for the sequences is:\n%s%s\n", strlen(rs)*2, rs, rs);
            }

            for (int k = 0; k < MAX; k++)
            {
                free(str_list[k]);
            }
            free(str_list);
            free(rs);
        }

        if (strcmp(argv[i], "-p") == 0)
        {
            if ((inp_file == NULL) && (strlen(s1) == 0))
            {
                // read in the input manually
                getString(s1);
            }

            char **str_list = (char **)malloc((MAX) * sizeof(char *)); // [rows][columns]
            for (int i = 0; i < MAX; i++)
            {
                str_list[i] = (char *)malloc((MAX) * sizeof(char));
                str_list[i][0] = '\0';
            }
            char *rs = (char *)malloc(MAX * sizeof(char));

            // how find the LCS for s1 and s2
            lps(s1, rs);

            // see if there is an output file

            if (!out_read)
            {
                printf("# an LPS (length = %zu) for the sequences is:\n%s\n", strlen(rs), rs);
            }
            else
            {
                fprintf(out_file, "# an LPS (length = %zu) for the sequences is:\n%s\n", strlen(rs), rs);
            }

            for (int k = 0; k < MAX; k++)
            {
                free(str_list[k]);
            }
            free(str_list);
            free(rs);
        }
    }
    
    if (inp_file != NULL)
        fclose(inp_file);
    if (out_file != NULL)
        fclose(out_file);
    free(s1);
    free(s2);
    return 0;
}

// Functionality 4: Longest Common Subseqeunce is a function
// Longest Tandem Subsequence is a function
// Longest palindromic subsequence is a function

// modify it to return all LCS instead of just one

// Functionality 3: Compute an LPS for the second string
// this is done by finding the LCS between a string and its reverse


// Functionality 2: Compute an LTS for the first string
// This is done by splitting the string into left and right, then finding the
// LCS between the right and left side
