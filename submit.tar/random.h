#define MAX 10000 + 1
