#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "lcs.h"
#include "random.h"

void lps(char s[], char lpsString[]);
void lcps(char s1[], char s2[], char rs[]);