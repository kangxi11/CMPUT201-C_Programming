#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "lcs.h"
#include "utility.h"
#include "random.h"
#include "lps.h"
#include "lts.h"


int c = 0;
int pos = 0;