#include "utility.h"

bool getString(char s[])
{
    printf("Enter a sequence: ");

    int i = 0;
    char ch;
    while ((ch = getchar()) != '\n')
    {
        if (ch < '0' || ch > '9')
        {
            printf("Error, non-digit character detected!\n");
            return true;
        }
        s[i++] = ch;
    }
    s[i] = '\0';
    return false;
}

void generate(int length, char s[])
{
    srand((unsigned)time(NULL)+(rand()%length));

    int i = 0;
    for (i = 0; i < length; i++)
    {
        s[i] = (rand() % 10) + '0';
    }
    s[i] = '\0';
}
