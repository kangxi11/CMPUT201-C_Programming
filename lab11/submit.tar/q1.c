#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#define INF 999999

void primMST(int n, int G[n][n]);
void kruskalMST(int n, int G[n][n]);

int main(int argc, char ** argv)
{
    // scan in a matrix
    int array_size = 0;

    scanf("%d", &array_size);

    int multi_array[array_size][array_size];
    int *p;

    for (p = &multi_array[0][0]; p <= &multi_array[array_size - 1][array_size - 1]; p++)
    {
        scanf("%d", &(*p));
    }

    primMST(array_size, multi_array);
    //kruskalMST(array_size, multi_array);

    return 0;
}

void primMST(int n, int G[n][n])
{
    int mst[n];
    int key[n];
    bool chosen[n];

    int min;
    int min_i;

    // set all keys to INFINITE
    // set all edges to not chosen yet
    for (int i = 0; i < n; i++)
    {
        key[i] = INF;
        chosen[i] = false;
    }

    // currently setting first to chosen
    key[0] = 0;
    mst[0] = -1;

    for (int i = 0; i < n-1; i++)
    {
        // pick the lowest cost edge out of the edges not picked yet
        min = INF;
        for (int j = 0; j < n; j++)
        {
            if ( (chosen[j] == false) && (key[j] < min))
            {
                min = key[j];
                min_i = j;
            }
        }

        chosen[min_i] = true;

        for (int x = 0; x < n; x++)
        {
            if ((G[min_i][x] > -1) && (chosen[x] == false) && (G[min_i][x] < key[x]))
            {
                mst[x] = min_i;
                key[x] = G[min_i][x];
            }
        }
    }

    for (int i = 1; i < n; i++)
        printf("(%d, %d, %d)\n", mst[i]+1, i+1, G[i][mst[i]]);
}
