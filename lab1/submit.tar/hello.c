#include <stdio.h> // the program lacked this line which is required for printf

int main()
{
  printf("Howdy\n");
  return 0;
}
